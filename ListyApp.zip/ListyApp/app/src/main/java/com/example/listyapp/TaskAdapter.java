package com.example.listyapp;

import android.app.AlertDialog; // <--- INI BUAT POPUP NYA
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Locale;

public class TaskAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<Task> taskList;      // List Tampil
    private ArrayList<Task> taskListFull;  // List Cadangan (Master)

    public TaskAdapter(Context context, ArrayList<Task> taskList) {
        this.context = context;
        this.taskList = taskList != null ? taskList : new ArrayList<>();
        this.taskListFull = new ArrayList<>(this.taskList);
    }

    // --- LOGIKA SEARCH ---
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        taskList.clear();

        if (charText.length() == 0) {
            taskList.addAll(taskListFull);
        } else {
            for (Task t : taskListFull) {
                if (t.getTitle().toLowerCase(Locale.getDefault()).contains(charText)) {
                    taskList.add(t);
                }
            }
        }
        notifyDataSetChanged();
    }

    // --- UPDATE DATA ---
    public void updateDataBaru(ArrayList<Task> newList) {
        this.taskList = new ArrayList<>(newList);
        this.taskListFull = new ArrayList<>(newList);
        notifyDataSetChanged();
    }

    @Override
    public int getCount() {
        if (taskList == null) return 0;
        return taskList.size();
    }

    @Override
    public Object getItem(int position) {
        return taskList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_task, parent, false);
        }

        final Task task = taskList.get(position);

        TextView tvName = convertView.findViewById(R.id.tvTaskName);
        CheckBox cbDone = convertView.findViewById(R.id.btnCheck);
        ImageView btnDelete = convertView.findViewById(R.id.btnDelete);

        tvName.setText(task.getTitle());

        // ==========================================
        // 1. LOGIC WARNA & CORETAN (JAVA ONLY)
        // ==========================================

        int warnaIjo = Color.parseColor("#4CAF50");
        int warnaMerah = Color.parseColor("#F44336");

        // Set Tampilan Awal
        if (task.isFinished()) {
            // -- SELESAI --
            tvName.setPaintFlags(tvName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            tvName.setTextColor(Color.GRAY);
            cbDone.setButtonTintList(ColorStateList.valueOf(warnaIjo));
        } else {
            // -- BELUM --
            tvName.setPaintFlags(tvName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
            tvName.setTextColor(Color.parseColor("#333333"));
            cbDone.setButtonTintList(ColorStateList.valueOf(warnaMerah));
        }

        // Reset listener
        cbDone.setOnCheckedChangeListener(null);
        cbDone.setOnClickListener(null);

        cbDone.setChecked(task.isFinished());

        // ==========================================
        // 2. PAS DI-KLIK CHECKBOX
        // ==========================================
        cbDone.setOnClickListener(v -> {
            boolean isChecked = cbDone.isChecked();
            task.setFinished(isChecked);

            if (isChecked) {
                // Jadi Ijo & Coret
                tvName.setPaintFlags(tvName.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                tvName.setTextColor(Color.GRAY);
                cbDone.setButtonTintList(ColorStateList.valueOf(warnaIjo));
            } else {
                // Jadi Merah & Normal
                tvName.setPaintFlags(tvName.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                tvName.setTextColor(Color.parseColor("#333333"));
                cbDone.setButtonTintList(ColorStateList.valueOf(warnaMerah));
            }

            // Update Master List
            for(Task t : taskListFull) {
                if(t == task) {
                    t.setFinished(isChecked);
                    break;
                }
            }

            // Simpan
            if (context instanceof MainActivity) {
                ((MainActivity) context).simpanPerubahanKeFile();
            }
        });

        // ==========================================
        // 3. LOGIC HAPUS DENGAN KONFIRMASI (POP-UP)
        // ==========================================
        if (btnDelete != null) {
            btnDelete.setOnClickListener(v -> {
                // Bikin Dialog Konfirmasi
                new AlertDialog.Builder(context)
                        .setTitle("Hapus Tugas")
                        .setMessage("Yakin mau hapus tugas '" + task.getTitle() + "'?")
                        .setPositiveButton("Hapus", (dialog, which) -> {
                            // Kalau pilih YES, baru hapus beneran
                            if (context instanceof MainActivity) {
                                ((MainActivity) context).hapusTugasBeneran(task);
                            }
                        })
                        .setNegativeButton("Batal", (dialog, which) -> {
                            // Kalau pilih NO, tutup aja
                            dialog.dismiss();
                        })
                        .show();
            });
        }

        return convertView;
    }
}