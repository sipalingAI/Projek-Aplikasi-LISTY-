package com.example.listyapp;

import android.content.Intent; // PENTING: Jangan lupa import ini
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // 1. Panggil Komponen
        // Pastikan ID di XML activity_settings.xml udah bener "btnBack" dan "menuAccount"
        ImageView btnBack = findViewById(R.id.btnBack);

        // Kita pake LinearLayout-nya aja sebagai tombol, biar area kliknya luas
        LinearLayout btnAccount = findViewById(R.id.menuAccount);

        // 2. Logika Tombol Back (Balik ke Home)
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // 3. Logika Klik Menu Account (Buka Halaman Akun/Logout)
        btnAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Pindah ke halaman AccountActivity
                Intent intent = new Intent(SettingsActivity.this, AccountActivity.class);
                startActivity(intent);
            }
        });

        // --- (Opsional) Kalau mau nambahin menu lain nanti disini ---
        // LinearLayout btnLanguage = findViewById(R.id.menuLanguage);
        // LinearLayout btnAbout = findViewById(R.id.menuAbout);
    }
}