package com.example.listyapp;

import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout; // Tambahan
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar; // WAJIB ADA INI

public class DetailActivity extends AppCompatActivity {

    EditText etTitle, etDetail;
    TextView tvTime;
    CheckBox cbStatus;
    Button btnSave;
    View btnBack;
    LinearLayout layoutTime; // Tambahan biar area klik makin luas

    int position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_task); // Pastikan nama XML bener

        // 1. Inisialisasi View
        etTitle = findViewById(R.id.etTaskTitle);
        etDetail = findViewById(R.id.etTaskDetail);
        tvTime = findViewById(R.id.tvTimePicker);
        cbStatus = findViewById(R.id.cbStatusDetail);
        btnSave = findViewById(R.id.btnSaveTask);
        btnBack = findViewById(R.id.btnBack);
        layoutTime = findViewById(R.id.layoutTime); // Ambil Layout Pembungkus Jam

        // 2. Ambil Data Lama dari MainActivity
        Intent intent = getIntent();
        if(intent != null) {
            String oldTitle = intent.getStringExtra("judul");
            String oldDetail = intent.getStringExtra("detail");
            String oldTime = intent.getStringExtra("jam");
            position = intent.getIntExtra("posisi", -1);
            boolean isFinished = intent.getBooleanExtra("status_tugas", false);

            etTitle.setText(oldTitle);
            etDetail.setText(oldDetail);

            // Pasang Jam Lama (Kalau ada)
            if (oldTime != null && !oldTime.isEmpty()) {
                tvTime.setText(oldTime);
            }

            if (cbStatus != null) {
                cbStatus.setChecked(isFinished);
            }
        }

        // ============================================================
        // [INI DIA SOLUSINYA] LOGIC MUNCULIN JAM
        // ============================================================
        View.OnClickListener bukaJam = v -> {
            // Ambil jam saat ini buat default
            Calendar calendar = Calendar.getInstance();
            int jamSekarang = calendar.get(Calendar.HOUR_OF_DAY);
            int menitSekarang = calendar.get(Calendar.MINUTE);

            // Munculin TimePickerDialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(DetailActivity.this,
                    (view, hourOfDay, minute) -> {
                        // Pas user pilih jam, format jadi 08:05
                        String jamFix = String.format("%02d:%02d", hourOfDay, minute);
                        tvTime.setText(jamFix); // Update teks di layar
                    }, jamSekarang, menitSekarang, true); // true = format 24 jam

            timePickerDialog.show();
        };

        // Pasang listenernya ke Teks DAN ke Layout pembungkusnya
        // Biar gampang dipencet
        tvTime.setOnClickListener(bukaJam);
        if (layoutTime != null) layoutTime.setOnClickListener(bukaJam);


        // 4. Logic Tombol Simpan
        btnSave.setOnClickListener(v -> {
            String judulBaru = etTitle.getText().toString();
            String detailBaru = etDetail.getText().toString();
            String jamBaru = tvTime.getText().toString();

            // Cek status Checkbox terbaru
            boolean statusBaru = (cbStatus != null) && cbStatus.isChecked();

            if (judulBaru.isEmpty()) {
                etTitle.setError("Judul harus diisi pren!");
                return;
            }

            Intent resultIntent = new Intent();
            resultIntent.putExtra("judul_baru", judulBaru);
            resultIntent.putExtra("detail_baru", detailBaru);
            resultIntent.putExtra("jam_baru", jamBaru);
            resultIntent.putExtra("status_baru", statusBaru); // Bawa status checkbox juga
            resultIntent.putExtra("posisi", position);

            setResult(RESULT_OK, resultIntent);
            finish();
        });

        // Tombol Back
        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
    }
}