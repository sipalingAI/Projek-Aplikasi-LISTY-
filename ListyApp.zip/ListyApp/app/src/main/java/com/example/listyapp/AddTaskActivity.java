package com.example.listyapp;

import android.app.AlarmManager; // [PENTING] Import ini
import android.app.DatePickerDialog;
import android.app.PendingIntent; // [PENTING] Import ini
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent; // [PENTING] Import ini
import android.content.SharedPreferences;
import android.os.Build; // [PENTING] Import ini
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AddTaskActivity extends AppCompatActivity {

    private EditText etTitle, etDetail;
    private Button btnSave;
    private ImageView btnBack;
    private LinearLayout layoutReminder;
    private TextView tvReminderStatus;

    private long selectedTime = System.currentTimeMillis();
    private Calendar calendar = Calendar.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_task);

        etTitle = findViewById(R.id.etTitle);
        etDetail = findViewById(R.id.etDetail);
        btnSave = findViewById(R.id.btnSaveTask);
        btnBack = findViewById(R.id.btnBack);
        layoutReminder = findViewById(R.id.layoutReminder);
        tvReminderStatus = findViewById(R.id.tvReminderStatus);

        if (btnBack != null) btnBack.setOnClickListener(v -> finish());
        if (layoutReminder != null) layoutReminder.setOnClickListener(v -> showDateTimePicker());

        btnSave.setOnClickListener(v -> prosesSimpanAman());
    }

    private void showDateTimePicker() {
        DatePickerDialog datePicker = new DatePickerDialog(this,
                (view, year, month, day) -> {
                    calendar.set(year, month, day);

                    TimePickerDialog timePicker = new TimePickerDialog(this,
                            (view1, hour, minute) -> {
                                calendar.set(Calendar.HOUR_OF_DAY, hour);
                                calendar.set(Calendar.MINUTE, minute);
                                calendar.set(Calendar.SECOND, 0);

                                selectedTime = calendar.getTimeInMillis();

                                SimpleDateFormat sdf = new SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault());
                                if (tvReminderStatus != null)
                                    tvReminderStatus.setText(sdf.format(calendar.getTime()));
                            },
                            calendar.get(Calendar.HOUR_OF_DAY),
                            calendar.get(Calendar.MINUTE), true);
                    timePicker.show();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH));

        // Minimal tanggal hari ini
        datePicker.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePicker.show();
    }

    private void prosesSimpanAman() {
        try {
            // A. Validasi
            String judul = etTitle.getText().toString().trim();
            String detail = etDetail != null ? etDetail.getText().toString().trim() : "";

            if (judul.isEmpty()) {
                etTitle.setError("Judul wajib diisi");
                return;
            }

            // B. Cek Login
            SharedPreferences session = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
            String email = session.getString("current_user", null);
            if (email == null) return;

            // C. Baca Data Lama
            SharedPreferences dataPrefs = getSharedPreferences("Data_V4_" + email, MODE_PRIVATE);
            Gson gson = new Gson();
            String jsonLama = dataPrefs.getString("task_list_v4", null);

            ArrayList<Task> listSementara = new ArrayList<>();
            if (jsonLama != null) {
                try {
                    Type type = new TypeToken<ArrayList<Task>>() {}.getType();
                    listSementara = gson.fromJson(jsonLama, type);
                } catch (Exception e) {}
            }
            if (listSementara == null) listSementara = new ArrayList<>();

            // D. [PENTING] BUAT TASK & FORMAT JAM
            long idUnik = System.currentTimeMillis(); // Ini dipake juga buat ID Alarm biar gak bentrok
            Task tugasBaru = new Task(judul, detail, idUnik);

            // Format Jam jadi String "HH:mm" buat disimpen (Display Only)
            SimpleDateFormat sdfJam = new SimpleDateFormat("HH:mm", Locale.getDefault());
            String jamString = sdfJam.format(new Date(selectedTime));
            tugasBaru.setTime(jamString);

            // Masukin ke list
            listSementara.add(tugasBaru);

            // E. SIMPAN KE FILE (DATABASE LOKAL)
            String jsonBaru = gson.toJson(listSementara);
            dataPrefs.edit().putString("task_list_v4", jsonBaru).apply();

            // F. UPDATE MAIN ACTIVITY LANGSUNG
            if (MainActivity.taskList != null) {
                MainActivity.taskList.add(tugasBaru);
                if (MainActivity.adapter != null) {
                    MainActivity.adapter.notifyDataSetChanged();
                }
            }

            // ===============================================================
            // G. [NYALAIN ALARM] Bagian ini yang LU LUPA Tadi!
            // Cek dulu, user milih waktunya masa depan atau masa lalu?
            // ===============================================================
            if (selectedTime > System.currentTimeMillis()) {
                aturAlarm(selectedTime, judul, idUnik);
                Toast.makeText(this, "Tugas Disimpan & Alarm Dinyalakan!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Tugas Disimpan (Tanpa Alarm karena waktu lewat)", Toast.LENGTH_SHORT).show();
            }

            finish();

        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(this, "Gagal: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ======================================================================
    // METHOD BARU BUAT REGISTER ALARM KE SISTEM ANDROID
    // ======================================================================
    private void aturAlarm(long waktuMillis, String judulTask, long idUnik) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", judulTask); // Kirim judul ke Receiver

        // PENTING: Pake idUnik (System.currentTimeMillis) sebagai RequestCode
        // Biar alarm A gak nimpah alarm B.
        int requestCode = (int) idUnik;

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                requestCode,
                intent,
                PendingIntent.FLAG_IMMUTABLE // Wajib buat Android 12+
        );

        // Pasang Alarm yang "Gak Bisa Tidur" (ExactAndAllowWhileIdle)
        // Biar tetep bunyi walau HP lagi mode hemat baterai
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, waktuMillis, pendingIntent);
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, waktuMillis, pendingIntent);
        }

        Log.d("ALARM_SET", "Alarm diset untuk: " + new Date(waktuMillis).toString());
    }
}