package com.example.listyapp;

import android.app.Notification; // Import ini
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes; // Import ini
import android.media.RingtoneManager; // Import ini
import android.net.Uri; // Import ini
import android.os.Build;
import android.util.Log; // Buat ngecek log
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;

public class ReminderReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Log.d("CEK_LISTY", "Receiver terpanggil! OTW bikin notif...");

            String taskTitle = intent.getStringExtra("title");
            if (taskTitle == null) taskTitle = "Ada tugas menanti!";

            showNotification(context, taskTitle);

        } catch (Exception e) {
            // Ini biar ketahuan kalo ada error diem-diem
            Log.e("CEK_LISTY", "Error di Receiver: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void showNotification(Context context, String title) {
        // 1. GANTI ID CHANNEL BIAR SETTINGAN LAMA DI-RESET
        String channelId = "listy_channel_v2";
        String channelName = "Listy Task Reminder";

        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        // Setup Suara Alarm Standard
        Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        // 2. Setup Channel (Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);

            channel.setDescription("Notifikasi pengingat tugas");
            channel.enableVibration(true); // Paksa Getar
            channel.setVibrationPattern(new long[]{100, 200, 300, 400, 500}); // Pola getar

            // Setup Suara di Channel (Penting buat Android 8+)
            AudioAttributes audioAttributes = new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .build();
            channel.setSound(alarmSound, audioAttributes);

            notificationManager.createNotificationChannel(channel);
        }

        // Intent buat buka aplikasi pas diklik
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        // 3. Rakit Notifikasinya
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, channelId)
                .setSmallIcon(R.drawable.baseline_check_circle_outline_1) // Pastikan file ini ada & vector
                .setColor(ContextCompat.getColor(context, R.color.white)) // Ganti ke warna biru lu
                .setContentTitle("ListyApp Reminder!")
                .setContentText("Jangan lupa: " + title)
                .setPriority(NotificationCompat.PRIORITY_HIGH) // Prioritas Tinggi
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true)
                .setSound(alarmSound) // Suara buat Android < 8
                .setVibrate(new long[]{100, 200, 300, 400, 500}) // Getar
                .setDefaults(Notification.DEFAULT_ALL); // Aktifin semua lampu/suara

        // TAMPILKAN!
        notificationManager.notify((int) System.currentTimeMillis(), builder.build());
        Log.d("CEK_LISTY", "Notifikasi harusnya udah muncul sekarang.");
    }
}