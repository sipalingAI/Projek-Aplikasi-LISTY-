package com.example.listyapp;

import android.Manifest; // [PENTING] Import Manifest buat Izin
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager; // [PENTING] Import ini
import android.os.Build; // [PENTING] Import ini
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat; // [PENTING] Buat requestPermission
import androidx.core.content.ContextCompat; // [PENTING] Buat checkPermission

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Task> taskList = new ArrayList<>();
    public static TaskAdapter adapter;
    private ListView listView;

    private static final int REQUEST_CODE_EDIT = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // ==================================================================
        // [TAMBAHAN WAJIB] MINTA IZIN NOTIFIKASI (ANDROID 13 / TIRAMISU)
        // Tanpa ini, notif lu bakal di-blokir sistem!
        // ==================================================================
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                    PackageManager.PERMISSION_GRANTED) {

                // Munculin Popup Minta Izin ke User
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }
        // ==================================================================

        // --- 1. AUTO LOGIN (Fitur Lama Lu Tetep Ada) ---
        SharedPreferences session = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        if (session.getString("current_user", null) == null) {
            session.edit().putString("current_user", "user_final_v4").apply();
        }

        // --- 2. Inisialisasi View ---
        listView = findViewById(R.id.listViewTasks);
        FloatingActionButton fab = findViewById(R.id.fabAdd);
        ImageView btnSettings = findViewById(R.id.btnSettings);
        EditText etSearch = findViewById(R.id.etSearch);

        // --- 3. Setup Adapter ---
        adapter = new TaskAdapter(this, taskList);
        listView.setAdapter(adapter);

        // Pas baris diklik -> Panggil method bukaHalamanEdit
        listView.setOnItemClickListener((parent, view, position, id) -> {
            Task taskYangDiklik = taskList.get(position);
            bukaHalamanEdit(taskYangDiklik);
        });

        // --- 4. Logic Search (Fitur Lama Lu) ---
        if (etSearch != null) {
            etSearch.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    if (adapter != null) adapter.filter(s.toString());
                }
                @Override
                public void afterTextChanged(Editable s) {}
            });
        }

        // --- 5. Tombol Settings ---
        if (btnSettings != null) {
            btnSettings.setOnClickListener(v -> {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            });
        }

        // --- 6. Tombol Tambah ---
        fab.setOnClickListener(v -> {
            startActivity(new Intent(MainActivity.this, AddTaskActivity.class));
        });

        // Load data awal
        loadData();
    }

    // [UPDATE] Paksa Refresh biar data gak kosong pas balik
    @Override
    protected void onResume() {
        super.onResume();
        loadData();
    }

    // [UPDATE] Link ke DetailTaskActivity
    public void bukaHalamanEdit(Task task) {
        Intent intent = new Intent(this, DetailActivity.class);
        intent.putExtra("judul", task.getTitle());
        intent.putExtra("detail", task.getDescription());
        intent.putExtra("status_tugas", task.isFinished());
        intent.putExtra("posisi", taskList.indexOf(task));
        startActivityForResult(intent, REQUEST_CODE_EDIT);
    }

    // Nangkep Data Balikan (Simpan Edit)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_CODE_EDIT && resultCode == RESULT_OK && data != null) {
            String judulBaru = data.getStringExtra("judul_baru");
            String detailBaru = data.getStringExtra("detail_baru");
            String jamBaru = data.getStringExtra("jam_baru");
            int posisi = data.getIntExtra("posisi", -1);

            if (posisi != -1 && posisi < taskList.size()) {
                Task taskYgDiedit = taskList.get(posisi);
                taskYgDiedit.setTitle(judulBaru);
                taskYgDiedit.setDescription(detailBaru);
                taskYgDiedit.setTime(jamBaru);

                simpanPerubahanKeFile();
                adapter.updateDataBaru(taskList);
                Toast.makeText(this, "Tugas berhasil diupdate!", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // --- Fungsi Load Data ---
    private void loadData() {
        SharedPreferences session = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        String currentUserEmail = session.getString("current_user", null);
        if (currentUserEmail == null) return;

        SharedPreferences dataPrefs = getSharedPreferences("Data_V4_" + currentUserEmail, MODE_PRIVATE);
        String json = dataPrefs.getString("task_list_v4", null);

        taskList.clear();

        if (json != null) {
            try {
                Gson gson = new Gson();
                Type type = new TypeToken<ArrayList<Task>>() {}.getType();
                ArrayList<Task> dataSimpanan = gson.fromJson(json, type);
                if (dataSimpanan != null) taskList.addAll(dataSimpanan);
            } catch (Exception e) { e.printStackTrace(); }
        }
        if (adapter != null) adapter.updateDataBaru(taskList);
    }

    // --- Fungsi Hapus ---
    public void hapusTugasBeneran(Task task) {
        taskList.remove(task);
        simpanPerubahanKeFile();
        if (adapter != null) adapter.updateDataBaru(taskList);
        Toast.makeText(this, "Tugas dihapus", Toast.LENGTH_SHORT).show();
    }

    // --- Fungsi Simpan ---
    public void simpanPerubahanKeFile() {
        SharedPreferences session = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        String currentUserEmail = session.getString("current_user", null);
        if (currentUserEmail != null) {
            SharedPreferences dataPrefs = getSharedPreferences("Data_V4_" + currentUserEmail, MODE_PRIVATE);
            String json = new Gson().toJson(taskList);
            dataPrefs.edit().putString("task_list_v4", json).apply();
        }
    }
}