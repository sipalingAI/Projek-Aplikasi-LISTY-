package com.example.listyapp;

public class Task {
    private String id;
    private String title;
    private boolean isFinished;

    // Data Baru
    private String description;
    private String time;

    // ==========================================
    // 1. CONSTRUCTOR KOSONG (Wajib buat Gson/Load Data)
    // ==========================================
    public Task() {
    }

    // ==========================================
    // 2. CONSTRUCTOR SIMPEL (Judul & Status doang)
    // ==========================================
    public Task(String title, boolean isFinished) {
        this.title = title;
        this.isFinished = isFinished;
        this.description = "";
        this.time = "";
        this.id = String.valueOf(System.currentTimeMillis());
    }

    // ==========================================
    // 3. CONSTRUCTOR LENGKAP (YANG LU BUTUHIN SEKARANG)
    // Ini biar AddTaskActivity lu ga error "Cannot resolve constructor"
    // ==========================================
    public Task(String title, String description, long id) {
        this.title = title;
        this.description = description;
        this.id = String.valueOf(id); // Ubah long ke String
        this.isFinished = false;      // Default belum selesai
        this.time = "";               // Default jam kosong
    }

    // ==========================================
    // GETTER & SETTER
    // ==========================================

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public boolean isFinished() { return isFinished; }
    public void setFinished(boolean finished) { isFinished = finished; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getTime() { return time; }
    public void setTime(String time) { this.time = time; }
}