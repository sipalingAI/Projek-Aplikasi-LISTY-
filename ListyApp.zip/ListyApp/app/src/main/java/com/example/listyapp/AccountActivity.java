package com.example.listyapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View; // Tambahan
import android.widget.Button;
import android.widget.ImageView; // Tambahan buat gambar panah
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class AccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account); // Pastikan XML-nya bener

        // 1. Inisialisasi View
        TextView tvEmail = findViewById(R.id.tvAccountEmail);
        Button btnLogout = findViewById(R.id.btnLogoutAction);

        // Cari ID tombol back yang kita buat di XML tadi
        ImageView btnBack = findViewById(R.id.btnBackToSettings);

        // 2. TAMPILIN DATA USER
        SharedPreferences session = getSharedPreferences("UserSession", MODE_PRIVATE);
        String currentUser = session.getString("current_user", "User");
        tvEmail.setText(currentUser);

        // =======================================================
        // 3. [BARU] LOGIC TOMBOL BACK
        // =======================================================
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                // finish() = Tutup halaman ini, otomatis balik ke halaman sebelumnya (MainActivity)
                finish();
            });
        }

        // =======================================================
        // 4. LOGIC LOGOUT DENGAN POP-UP (ALERT DIALOG)
        // =======================================================
        btnLogout.setOnClickListener(v -> {

            // Bikin Pop-up Konfirmasi
            new AlertDialog.Builder(AccountActivity.this)
                    .setTitle("Keluar Akun?")
                    .setMessage("Apakah kamu yakin ingin keluar dari aplikasi?")
                    .setPositiveButton("Ya, Keluar", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            // --- PROSES LOGOUT DI SINI ---

                            // A. Hapus Data Sesi
                            SharedPreferences.Editor editor = session.edit();
                            editor.clear(); // Hapus status login
                            editor.apply();

                            Toast.makeText(AccountActivity.this, "Dadah " + currentUser + "! 👋", Toast.LENGTH_SHORT).show();

                            // B. PINDAH KE WELCOME ACTIVITY
                            Intent intent = new Intent(AccountActivity.this, WelcomeActivity.class);

                            // Mantra Sakti: Hapus History Belakang (biar gak bisa di-back balik ke sini)
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);

                            startActivity(intent);
                            finish();
                        }
                    })
                    .setNegativeButton("Batal", null) // Kalau Batal, gak ngapa-ngapain
                    .show();
        });
    }
}