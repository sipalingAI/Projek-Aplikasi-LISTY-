package com.example.listyapp; // Sesuaikan package kamu

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Timer 3 Detik (3000 ms)
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Pindah dari Splash ke Main
                Intent intent = new Intent(SplashActivity.this, WelcomeActivity.class);
                startActivity(intent);
                finish(); // Tutup splash biar gak bisa di-back
            }
        }, 3000);
    }
}