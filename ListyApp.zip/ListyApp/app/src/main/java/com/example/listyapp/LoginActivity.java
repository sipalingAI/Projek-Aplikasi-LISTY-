package com.example.listyapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 1. CEK SESI
        // Kalau user buka aplikasi dan ternyata statusnya masih Login:
        // Langsung lempar ke MainActivity, tutup LoginActivity.
        SharedPreferences session = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        if (session.getBoolean("isLoggedIn", false)) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        final EditText etEmail = findViewById(R.id.etEmailLog);
        final EditText etPass = findViewById(R.id.etPassLog);
        Button btnToLogin = findViewById(R.id.btnToLogin);
        ImageView btnBack = findViewById(R.id.btnBackLog);

        // 2. LOGIKA TOMBOL BACK DI LAYAR (Tombol Panah Kiri)
        // Ini cuma buat kalau user "Batal Login" dan mau balik ke Welcome
        if (btnBack != null) {
            btnBack.setOnClickListener(v -> {
                Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
                startActivity(intent);
                finish();
            });
        }

        // 3. LOGIKA TOMBOL LOGIN
        btnToLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputUser = etEmail.getText().toString().trim();
                String inputPass = etPass.getText().toString().trim();

                if(inputUser.isEmpty() || inputPass.isEmpty()){
                    Toast.makeText(LoginActivity.this, "Masukan Nama Pengguna!", Toast.LENGTH_SHORT).show();
                    return;
                }

                SharedPreferences accountPrefs = getSharedPreferences("ListyAccounts", Context.MODE_PRIVATE);
                String registeredPass = accountPrefs.getString(inputUser, null);

                if (registeredPass == null) {
                    Toast.makeText(LoginActivity.this, "Nama Pengguna tidak ditemukan!", Toast.LENGTH_SHORT).show();
                }
                else if (!registeredPass.equals(inputPass)) {
                    Toast.makeText(LoginActivity.this, "Sandi Salah!", Toast.LENGTH_SHORT).show();
                }
                else {
                    // --- LOGIN BERHASIL ---

                    // A. Simpan Sesi
                    SharedPreferences.Editor editor = session.edit();
                    editor.putString("current_user", inputUser);
                    editor.putBoolean("isLoggedIn", true);
                    editor.apply();

                    Toast.makeText(LoginActivity.this, "Masuk Sukses! Selamat Datang " + inputUser, Toast.LENGTH_SHORT).show();

                    // B. PINDAH KE MAIN ACTIVITY
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);

                    // C. [PENTING] HAPUS SEMUA HALAMAN SEBELUMNYA
                    // Kode ini bikin MainActivity jadi halaman PERTAMA lagi.
                    // Jadi WelcomeActivity & LoginActivity dihapus dari memori.
                    // Efeknya: Pas di MainActivity tekan Back -> Langsung EXIT APLIKASI.
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);

                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}