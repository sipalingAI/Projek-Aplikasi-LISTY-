package com.example.listyapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView; // Import buat tombol Google

public class WelcomeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // --- [1. LOGIKA "SATPAM" OTOMATIS] ---
        // Cek dulu, kalau user udah login, langsung tendang ke Home (MainActivity)
        // Jadi gak usah liat halaman Welcome ini lagi.
        SharedPreferences session = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        boolean sudahLogin = session.getBoolean("isLoggedIn", false);

        if (sudahLogin) {
            Intent intent = new Intent(WelcomeActivity.this, MainActivity.class);
            startActivity(intent);
            finish();
            return;
        }

        // --- Kalau belum login, baru tampilin layout Welcome ---
        setContentView(R.layout.activity_welcome);

        // 2. Inisialisasi Komponen sesuai ID di XML lu
        Button btnDaftar = findViewById(R.id.btnToSignUp); // Tombol Daftar
        Button btnMasuk  = findViewById(R.id.btnToLogin);  // Tombol Masuk
        CardView btnGoogle = findViewById(R.id.btnGoogle); // Tombol Google

        // 3. Logika Tombol DAFTAR -> Ke RegisterActivity
        btnDaftar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this, SignupActivity.class);
                startActivity(intent);
            }
        });

        // 4. Logika Tombol MASUK -> Ke LoginActivity
        btnMasuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });

        // 5. Logika Tombol GOOGLE (Sementara dikasih Toast dulu)
        btnGoogle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(WelcomeActivity.this, "Fitur Google Login Segera Hadir!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}