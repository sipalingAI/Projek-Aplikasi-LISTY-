package com.example.listyapp;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        // 1. PANGGIL KOMPONEN (ID SESUAI XML)
        ImageView btnBack = findViewById(R.id.btnBackSign);

        // Lu bilang pake userreg, oke variabelnya kita sesuaikan
        final EditText etUser = findViewById(R.id.etEmailSign);
        final EditText etPass = findViewById(R.id.etPassSign);
        final EditText etConfirm = findViewById(R.id.etConfirmPassSign);

        Button btnReg = findViewById(R.id.btnToSignUp);

        // 2. TOMBOL BACK
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        // 3. TOMBOL SIGN UP (DAFTAR)
        btnReg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String inputUser = etUser.getText().toString().trim(); // Pake trim biar rapi
                String inputPass = etPass.getText().toString().trim();
                String inputConfirm = etConfirm.getText().toString().trim();

                // Validasi: Cek kosong
                if(inputUser.isEmpty() || inputPass.isEmpty() || inputConfirm.isEmpty()){
                    Toast.makeText(SignupActivity.this, "Isi semua terlebih dahulu!", Toast.LENGTH_SHORT).show();
                }
                // Validasi: Cek Password sama Confirm
                else if (!inputPass.equals(inputConfirm)) {
                    Toast.makeText(SignupActivity.this, "Sandi tidak sama!", Toast.LENGTH_SHORT).show();
                }
                else {
                    // --- BAGIAN INI YANG GUA UBAH PREN ---

                    // 1. Nama File Penyimpanan HARUS SAMA dengan yang di LoginActivity
                    // Tadi di Login kita pake "ListyAccounts", jadi disini harus sama!
                    SharedPreferences prefs = getSharedPreferences("ListyAccounts", Context.MODE_PRIVATE);

                    // 2. Cek dulu, username ini udah dipake orang lain belum?
                    if (prefs.contains(inputUser)) {
                        Toast.makeText(SignupActivity.this, "Nama Pengguna ini telah digunakan, gunakan yang lain!", Toast.LENGTH_SHORT).show();
                    } else {
                        // 3. SIMPAN DATA (KUNCI UTAMA)
                        SharedPreferences.Editor editor = prefs.edit();

                        // RUMUS: KEY = Username, VALUE = Password
                        // Jadi: Laci "udin" isinya "1234"
                        editor.putString(inputUser, inputPass);

                        editor.apply();

                        Toast.makeText(SignupActivity.this, "Akun berhasil dibuat. Silakan Login.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }
            }
        });
    }
}